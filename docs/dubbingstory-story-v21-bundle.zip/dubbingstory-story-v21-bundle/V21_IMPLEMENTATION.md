# DubbingStory V2.1 MVP Implementation

This branch implements the reviewed V2.1 recap architecture on top of the Vision Architecture Fix.

## Enable

Use either:

```bash
STORY_V21_ENABLED=true
```

or:

```bash
python main.py run ... --mode summary --story-v21
```

For multilingual post-write semantic verification, install:

```bash
pip install "sentence-transformers>=3.0.0"
```

If sentence-transformers/model loading is unavailable, pre-write matching falls back to deterministic lexical similarity and post-write verification is explicitly marked `degraded` rather than triggering unsafe cross-language repairs.

## Implemented

- bounded scene-window identity contract: `parent_scene_id`, `window_id`, `window_index`, `window_count`;
- shared boundary keyframe anchor between adjacent windows of the same long shot;
- `scene_delta.json`: deterministic local continuity with optional Gemini refinement;
- `scene_signatures.json`: action/state/object/goal/continuity/transcript representation;
- `beats.json`: structured beat planning with deterministic fallback and anti-overcollapse dedup guard;
- `prewrite_match.json`: top-K beat-to-scene matching with temporal score, continuity/state score, reuse penalty, parent-shot penalty, redundancy penalty, and strict chronological guard;
- matched `narration_plan.json` using beat IDs plus `covers_scene_ids`;
- true rolling narration writer: each beat receives the actual previous generated narration;
- `match_report.json`: post-write narration/claim verification;
- targeted rewrite for failed post-write semantic checks;
- `script_qa.json`: deterministic structural/semantic QA before TTS;
- V2 legacy behavior remains available when `story_v21.enabled=false`.

## Output artifacts

With V2.1 enabled, the project directory may contain:

```text
scene_cards.json
scene_delta.json
scene_signatures.json
story_plan.json
story_memory.json
beats.json
prewrite_match.json
narration_plan.json
match_report.json
script_qa.json
summary_manifest.json
scripts/
audio/
final_summary_*.mp4
```

## Deliberately deferred

The reviewed plan places these after the MVP and they are not enabled here:

- LLM whole-script judge and deterministic judge-verdict derivation;
- automatic footage rematch after a post-write failure (candidate audit is already retained; targeted narration rewrite is implemented);
- rhythm/emotion scoring;
- faster-whisper generated-TTS alignment QA;
- emotion-aware BGM/TTS;
- full-mode V2.1 matching (this MVP targets `--mode summary`).

## Validation performed

- `python -m compileall -q dubbingstory`
- deterministic V2.1 unit tests: long-scene metadata, bounded/chronological matcher, deterministic script QA;
- deterministic dry run on the supplied real storyboard: 141 scene cards -> 141 deltas -> 16 planned beats -> 13 chronologically selected windows, about 164 s selected for a 180 s target, within the hard 1.05 duration tolerance;
- `git diff --check`.

GPU/vLLM, Gemini API calls, TTS, and final video rendering must still be validated in the target Kaggle/Colab runtime.
