# Apply and Test - DubbingStory Story V2.1 MVP

## Recommended path

The easiest artifact is:

```text
dubbingstory-story-v21-source.zip
```

It already includes the previous Vision Architecture Fix plus the Story V2.1 MVP implementation.

## Git patch path

`dubbingstory-story-v21.patch` is generated against the previously delivered Vision Architecture Fix source.

From a branch that already contains that fix:

```bash
git checkout -b story-v21
git apply --check dubbingstory-story-v21.patch
git apply dubbingstory-story-v21.patch
git status
git add .
git commit -m "feat: implement story v2.1 grounded recap pipeline"
```

Or preserve the generated commit metadata:

```bash
git am dubbingstory-story-v21-git-am.patch
```

Generated implementation commit:

```text
3113f0cad5796ecec9369c7ccac270aab01670e2
```

## Enable V2.1

The default YAML keeps V2.1 disabled for backward compatibility.

Choose one:

```bash
export STORY_V21_ENABLED=true
```

or:

```bash
python main.py run ... --mode summary --story-v21
```

The provided Kaggle/Colab V2.1 notebooks already set:

```python
STORY_V21_ENABLED = True
```

and add `--story-v21` automatically.

## Semantic embedding dependency

The V2.1 notebooks install:

```bash
pip install "sentence-transformers>=3.0.0"
```

The default embedding model is:

```text
sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2
```

It is configured on CPU so both T4 GPUs can remain available for Qwen/vLLM replicas.

If embeddings are unavailable:

```text
pre-write matching -> deterministic lexical fallback
post-write verifier -> explicit degraded status
```

The system does not perform false cross-language repair from lexical scores.

## New runtime artifacts

With Story V2.1 enabled:

```text
outputs/<project>/scene_delta.json
outputs/<project>/scene_signatures.json
outputs/<project>/beats.json
outputs/<project>/prewrite_match.json
outputs/<project>/narration_plan.json
outputs/<project>/match_report.json
outputs/<project>/script_qa.json
```

Existing V2 artifacts remain available.

## Local validation commands

```bash
python -m compileall -q dubbingstory
PYTHONPATH=. HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 pytest -q tests/test_story_v21.py
git diff --check
```

See `DUBBINGSTORY_V21_VALIDATION.txt` for the validation performed before packaging.

## First Kaggle A/B run

Keep the same vision model for the first comparison:

```text
Qwen/Qwen3-VL-2B-Instruct
MAX_KEYFRAMES=3
MAX_SCENE_DURATION=15
VISION_MAX_TOKENS=640
STORY_V21_ENABLED=True
```

Do not switch to 4B/8B in the same first test. First compare architecture quality with the same 2B model.

Recommended comparison:

```text
V2 + Vision Architecture Fix, STORY_V21_ENABLED=False
vs
V2.1 MVP, STORY_V21_ENABLED=True
```

Inspect especially:

```text
scene_delta.json
beats.json
prewrite_match.json
match_report.json
script_qa.json
summary_manifest.json
pipeline.log
```

## Scope intentionally deferred

This MVP does not yet enable:

- whole-script LLM judge;
- automatic post-write footage rematch;
- rhythm/emotion scoring;
- generated-TTS faster-whisper alignment QA;
- full-mode Story V2.1 matching.

Those remain later phases from the reviewed plan.
