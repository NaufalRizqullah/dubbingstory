# Cara menerapkan DubbingStory v2

## Opsi A — Git patch (disarankan)

Copy `dubbingstory-v2-storytelling.patch` ke root repo, lalu:

```bash
git apply --check dubbingstory-v2-storytelling.patch
git apply dubbingstory-v2-storytelling.patch
pip install -r requirements.txt
python -m compileall -q dubbingstory
python -m unittest -q tests/test_storytelling_v2.py
```

Setelah dicek:

```bash
git add .
git commit -m "Implement DubbingStory v2 storytelling pipeline"
git push origin main
```

## Opsi B — Copy/replacement

Copy seluruh isi folder `replacement-files/` ke root repository dengan struktur folder tetap sama, lalu commit/push.

## First rerun

Untuk perbandingan pertama, tetap gunakan Qwen/Qwen3-VL-2B-Instruct dan `max-model-len=12288`.
Per-scene vision output sekarang dibatasi 640 token.

Default TTS masih `edge`. Opsi `--engine chirp` tersedia, tetapi Google Chirp membutuhkan Google Cloud ADC credentials, bukan `GOOGLE_API_KEY` Gemini.
